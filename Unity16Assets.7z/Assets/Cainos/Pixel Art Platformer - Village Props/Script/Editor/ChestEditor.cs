
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using Cainos.LucidEditor;

namespace Cainos.PixelArtPlatformer_VillageProps
{
    [CustomEditor(typeof(Chest))]
    public class ChestEditor : Cainos.LucidEditor.LucidEditor
    {
    }
}
