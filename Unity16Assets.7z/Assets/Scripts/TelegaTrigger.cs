using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TelegaTrigger : MonoBehaviour
{
    bool inTrigger = false;
    [SerializeField] WheelJoint2D wheelJoint;

    [SerializeField] TMP_Text text;
    string previousText;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            previousText = text.text;
            inTrigger = true;
            text.text = "E - �������� ������"; 
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        inTrigger = false;
        text.text = previousText;
    }

    private void Update()
    {
        if (inTrigger&& Input.GetKeyDown(KeyCode.E))           
        {
            wheelJoint.useMotor = true;
            gameObject.SetActive(false);
        }
    }
}
