using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class LivesCounter : MonoBehaviour
{
    int lifes;
    [SerializeField] TMP_Text lifesText;
    public bool isALive = true;

    private void Awake()
    {
        lifes = 3;
        UpdateLifesText();
    }

    public void DecreseLifes()
    { 
        lifes--;
        if (lifes<=0)
        {
            isALive = false;
        }
        UpdateLifesText() ;
    }

    void UpdateLifesText()
    {
        lifesText.text = lifes.ToString();
    }
}
